<?php
require __DIR__ . '/parts/connect_db.php';

$sql = "SELECT `sid` FROM `mountain` where `coupon_status` = '1'";

$stmt = $pdo->query($sql)->fetchAll();

echo json_encode($stmt, JSON_UNESCAPED_UNICODE);