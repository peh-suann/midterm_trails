<?php require __DIR__ . '/parts/connect_db.php' ?>
<?php
$pageName = "achieve";
$title = "achieve";
?>
<?php require __DIR__ . '/parts/html-head.php' ?>
<?php require __DIR__ . '/parts/navbar.php' ?>
<h2>Hello word~</h2>
<?php require __DIR__ . '/parts/scripts.php' ?>
<?php require __DIR__ . '/parts/html-foot.php' ?>