<?php require __DIR__ . '/parts/connect_db.php' ?>
<?php
$pageName = "comment";
$title = "comment";
?>
<?php require __DIR__ . '/parts/html-head.php' ?>
<?php require __DIR__ . '/parts/navbar.php' ?>
<h6>comment</h6>
<?php require __DIR__ . '/parts/scripts.php' ?>
<?php require __DIR__ . '/parts/html-foot.php' ?>